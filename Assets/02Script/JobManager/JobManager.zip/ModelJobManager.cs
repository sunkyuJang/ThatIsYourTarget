using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using JobManager;

public class ModelHandlerJobManager : JobManager
{
    ISectionJobChecker sectionJobChecker;
    Job parentJob;
    IJobStarter naviJobStarter;
    IJobStarter aniJobStarter;
    ActionPointHandler aph;
    enum JobKind { naviJob, aniJob, nextJob, SetNextJob, doneJob, non }
    public ModelHandlerJobManager(Action doEndJob, IJobStarter naviJobStarter, IJobStarter aniJobStarter, Job parentJob, ActionPointHandler aph, ISectionJobChecker sectionJobChecker)
        : base(null, doEndJob)
    {
        this.sectionJobChecker = sectionJobChecker;
        this.parentJob = parentJob;
        this.naviJobStarter = naviJobStarter;
        this.aniJobStarter = aniJobStarter;
        this.aph = aph;
        jobList = CreatingJob(parentJob);
    }

    Queue<Action> CreatingJob(Job parentJob)
    {
        var jobList = new Queue<Action>();
        var nowAP = aph.GetNowActionPoint();
        var isAPHDone = aph.isAPHDone;
        var state = isAPHDone ? (int)JobKind.doneJob : 0;
        for (int i = state; i < (int)JobKind.non; i++)
        {
            Action action = null;
            switch ((JobKind)i)
            {
                case JobKind.naviJob:
                    {
                        action = (new ModelHandler.ModelHandlerJob
                                    (
                                        sectionChecker: sectionJobChecker,
                                        walkingState: aph.walkingState,
                                        ap: nowAP,
                                        job: parentJob,
                                        starter: naviJobStarter,
                                        endAction: StartJob,
                                        exceptionAction: null
                                    )
                                ).StartJob;
                    }
                    break;
                case JobKind.aniJob:
                    {
                        if (nowAP.HasAction)
                            action = (new ModelHandler.ModelHandlerJob
                                        (
                                            sectionChecker: sectionJobChecker,
                                            walkingState: aph.walkingState,
                                            ap: nowAP,
                                            job: parentJob,
                                            starter: aniJobStarter,
                                            endAction: StartJob,
                                            exceptionAction: null
                                        )
                                    ).StartJob;
                        else continue;
                    }
                    break;
                case JobKind.nextJob:
                    {
                        action = ReadNextAP;
                    }
                    break;
                case JobKind.doneJob:
                    if (isAPHDone)
                        action = EndJob;
                    break;
            }

            if (action != null)
                jobList.Enqueue(action);
        }
        return jobList;
    }

    void ReadNextAP()
    {
        aph.GetNextActionPoint();
        CreatingJob(parentJob);
    }
}
