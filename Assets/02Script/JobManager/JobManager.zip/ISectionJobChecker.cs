using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISectionJobChecker
{
    bool IsSameSection(Job job);
}
